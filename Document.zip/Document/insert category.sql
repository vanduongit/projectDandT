
INSERT INTO `category` (`ID`, `TAG`, `NAME`, `CONTENT`, `LEVEL`, `PRIORITY`, `INDEX`, `IMAGE`, `TITLE`, `DESCRIPTION`, `KEYWORD`, `ACTIVE`, `ORD`, `LANG`, `IMAGE2`) VALUES
(1, 'aa', 'Category1', 'Content of Category 1', 1, 1, 1, 'image.jpg', 'aaaa', 'DESCRIPTION', 'KEYWORD', 0, 0, 'LANG', 'IMAGE2');
