
INSERT INTO `brand` (`ID`, `NAME`, `LOGO`, `ORD`, `LANG`) VALUES
(1, 'Distributor 1', 'distributor1.jpg', 1, 'VN'),
(2, 'Distributor 2', 'distributor2.jpg', 1, 'VN'),
(3, 'Distributor 3', 'distributor3.jpg', 1, 'VN'),
(4, 'Distributor 4', 'distributor4.jpg', 1, 'VN');